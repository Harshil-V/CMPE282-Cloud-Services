//
//  ColorUtils.swift
//  FinalProject
//
//  Created by Ahmed Zaytoun on 4/21/24.
//

import SwiftUI

public func getCourseColor(_ id: Int) -> Color {
    switch id {
    case 1:
        return .blue
    case 2:
        return .brown
    case 3:
        return .green
    case 4:
        return .cyan
    case 5:
        return .purple
    case 6:
        return .gray
    case 7:
        return .red
    case 8:
        return .indigo
    case 9:
        return .orange
    case 10:
        return .teal
    default:
        return .blue
    }
}

