//
//  CourseDetailsSectionCellView.swift
//  FinalProject
//
//  Created by Ahmed Zaytoun on 4/21/24.
//

import SwiftUI

struct CourseDetailsSectionCellView: View {
    let title: String
    let icon: String
    var body: some View {
        HStack(spacing:0.0) {
            Image(systemName: self.icon)
                .padding(10)
            Text(self.title)
            Spacer()
        }
    }
}

#Preview {
    CourseDetailsSectionCellView(title: "Test", icon: "eye")
}
