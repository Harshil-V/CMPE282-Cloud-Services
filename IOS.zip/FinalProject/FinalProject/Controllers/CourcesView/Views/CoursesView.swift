//
//  CourcesView.swift
//  FinalProject
//
//  Created by Ahmed Zaytoun on 4/21/24.
//

import SwiftUI

struct CoursesView: View {
    @ObservedObject var viewModel: CoursesViewModel
    var body: some View {
        CoursesListView(viewModel: self.viewModel)
            .task {
                await self.viewModel.loadCourses()
            }
    }
}

#Preview {
    CoursesView(viewModel: CoursesViewModel())
}
