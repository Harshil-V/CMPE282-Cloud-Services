//
//  CourcesListView.swift
//  FinalProject
//
//  Created by Ahmed Zaytoun on 4/21/24.
//

import SwiftUI

struct CoursesListView: View {
    @ObservedObject var viewModel: CoursesViewModel
    var body: some View {
        List {
            Section(header: Text("Spring 2024 (Current)")) {
                ForEach(self.viewModel.currentCourses) { cell in
                    NavigationLink(destination: {
                        CourseDetailsView(viewModel: CourseDetailsViewModel(course: cell.course))
                    }, label: {
                        CourseCellView(viewModel: cell)
                    })
                }
            }
            Section(header: Text("Fall 2023")) {
                ForEach(self.viewModel.lastCourses) { cell in
                    CourseCellView(viewModel: cell)
                }
            }
        }
        .listStyle(.plain)
    }
}

#Preview {
    CoursesListView(viewModel: CoursesViewModel())
}
