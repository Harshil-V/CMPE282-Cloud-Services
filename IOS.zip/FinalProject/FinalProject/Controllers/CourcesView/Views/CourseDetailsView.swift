//
//  CourseDetailsView.swift
//  FinalProject
//
//  Created by Ahmed Zaytoun on 4/21/24.
//

import SwiftUI

struct CourseDetailsView: View {
    @ObservedObject var viewModel: CourseDetailsViewModel
    
    var body: some View {
        VStack(spacing:0.0){
            Rectangle()
                .fill(self.viewModel.color)
                .frame(height: 5.0)
            Divider()
            HStack{
                Text(self.viewModel.semester)
                    .padding(10.0)
                Spacer()
            }
            Divider()
            List {
                NavigationLink(destination: {
                    CourseContentView(title: "\(viewModel.title) Content", content: "Bla bla bla\nbla bla bla")
                }, label: {
                    CourseDetailsSectionCellView(title: "Content", icon: "menucard")
                })
                .listRowInsets(EdgeInsets(top: 10.0, leading: 0.0, bottom: 10.0, trailing: 10.0))
                
                NavigationLink(destination: {
                    
                }, label: {
                    CourseDetailsSectionCellView(title: "Assignments", icon: "pencil.and.ruler")
                })
                .listRowInsets(EdgeInsets(top: 10.0, leading: 0.0, bottom: 10.0, trailing: 10.0))
                
                NavigationLink(destination: {
                    
                }, label: {
                    CourseDetailsSectionCellView(title: "Quizes", icon: "studentdesk")
                })
                .listRowInsets(EdgeInsets(top: 10.0, leading: 0.0, bottom: 10.0, trailing: 10.0))
                
                NavigationLink(destination: {
                    
                }, label: {
                    CourseDetailsSectionCellView(title: "Grades", icon: "trophy")
                })
                .listRowInsets(EdgeInsets(top: 10.0, leading: 0.0, bottom: 10.0, trailing: 10.0))
            }
            .listStyle(.plain)
        }
        .navigationTitle(self.viewModel.title)
    }
}

#Preview {
    CourseDetailsView(viewModel: CourseDetailsViewModel(course: Course(id: 1, title: "")))
}
