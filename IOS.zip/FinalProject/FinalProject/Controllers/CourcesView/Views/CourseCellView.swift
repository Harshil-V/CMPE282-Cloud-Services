//
//  CourseCellView.swift
//  FinalProject
//
//  Created by Ahmed Zaytoun on 4/21/24.
//

import SwiftUI

struct CourseCellView: View {
    @ObservedObject var viewModel: CourseCellViewModel
    var body: some View {
        VStack(spacing: 0.0){
            Rectangle()
                .fill(self.viewModel.color)
                .frame(height: 50.0)
            Divider()
            HStack {
                Text(self.viewModel.title)
                    .foregroundStyle(self.viewModel.color)
                    .font(.system(size: 19.0))
                    .padding(.top, 5.0)
                Spacer()
            }
            HStack {
                Text(self.viewModel.desc)
                    .foregroundStyle(.black)
                    .font(.system(size: 14.0))
                    .padding(.top, 5.0)
                Spacer()
            }
        }
        .padding(.bottom, 15.0)
    }
}

#Preview {
    CourseCellView(viewModel: CourseCellViewModel(course: Course(id: 1, title: "")))
}
