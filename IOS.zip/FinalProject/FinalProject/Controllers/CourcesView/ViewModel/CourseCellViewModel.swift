//
//  CourseCellViewModel.swift
//  FinalProject
//
//  Created by Ahmed Zaytoun on 4/21/24.
//

import Foundation
import SwiftUI

class CourseCellViewModel: ObservableObject, Identifiable {
    
    public let course: Course
    
    @Published public private(set) var color: Color = .red
    
    init(course: Course) {
        self.course = course
        self.color = getCourseColor(course.id)
    }
    
    let id = UUID()
    
    public var title: String {
        get {
            return self.course.title
        }
    }
    
    public var desc: String {
        get {
            return self.course.title
        }
    }
    
}
