//
//  CourseDetailsViewModel.swift
//  FinalProject
//
//  Created by Ahmed Zaytoun on 4/21/24.
//

import SwiftUI

class CourseDetailsViewModel: ObservableObject {
    
    public let course: Course
    
    init(course: Course) {
        self.course = course
    }
    
    public var title: String {
        get {
            self.course.title
        }
    }
    
    public var color: Color {
        get {
            getCourseColor(course.id)
        }
    }
    
    public var semester: String {
        get {
            "Spring 2024"
        }
    }
}
