//
//  CourcesViewModel.swift
//  FinalProject
//
//  Created by Ahmed Zaytoun on 4/21/24.
//

import Foundation

@MainActor
class CoursesViewModel: ObservableObject {
 
    @Published public private(set) var currentCourses: [CourseCellViewModel] = []
    @Published public private(set) var lastCourses: [CourseCellViewModel] = []
    
    init() {
        
    }
    
    public func loadCourses() async {
        
        self.currentCourses = (1..<5).map { id in CourseCellViewModel(course: Course(id: id, title: "Course \(id)"))}
        self.lastCourses = (5..<9).map { id in CourseCellViewModel(course: Course(id: id, title: "Course \(id)"))}
    }
}
