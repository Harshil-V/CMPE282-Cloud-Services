//
//  CourseContentView.swift
//  FinalProject
//
//  Created by Ahmed Zaytoun on 4/22/24.
//

import SwiftUI

struct CourseContentView: View {
    let title: String
    let content: String
    var body: some View {
        ScrollView {
            HStack{
                Text(self.content)
                    .multilineTextAlignment(.leading)
                    .padding(10.0)
                Spacer()
            }
            
        }
        .navigationTitle(self.title)
    }
}

#Preview {
    CourseContentView(title: "", content: "")
}
