//
//  AssignmentsView.swift
//  FinalProject
//
//  Created by Ahmed Zaytoun on 4/22/24.
//

import SwiftUI

struct AssignmentsView: View {
    @ObservedObject var viewModel: AssignmentsViewModel
    var body: some View {
        List{
            Section("Due Assignments"){
                
            }
            Section("Overdue Assignments"){
                
            }
        }
        .navigationTitle("Assignments")
    }
}

#Preview {
    AssignmentsView(viewModel: AssignmentsViewModel())
}
