//
//  AssignmentListCellView.swift
//  FinalProject
//
//  Created by Ahmed Zaytoun on 4/22/24.
//

import SwiftUI

struct AssignmentListCellView: View {
    @ObservedObject var viewModel: AssignmentViewModel
    var body: some View {
        HStack(spacing: 0.0) {
            self.viewModel.icon
                .padding()
            VStack(spacing: 0.0) {
                HStack{
                    Text(self.viewModel.title)
                    Spacer()
                }
                .padding(.bottom, 5.0)
                HStack{
                    Text(self.viewModel.due)
                        .font(.system(size: 12.0))
                        .foregroundStyle(.gray)
                    Spacer()
                }
            }
            Spacer()
        }
    }
}

#Preview {
    AssignmentListCellView(viewModel: AssignmentViewModel(assignment: Assignment(id: 1, title: "", description: "", due: nil, mark: 10.0, grade: nil)))
}
