//
//  AssignmentsViewModel.swift
//  FinalProject
//
//  Created by Ahmed Zaytoun on 4/22/24.
//

import Foundation

@MainActor
class AssignmentsViewModel: ObservableObject {
    
    @Published public private(set) var dueAssignments: [AssignmentViewModel] = []
    @Published public private(set) var overdueAssignments: [AssignmentViewModel] = []
    
    public func loadAssignments() async {
        
        self.dueAssignments = (1..<5).map { i in
            let id = Int(i)
            return AssignmentViewModel(assignment: Assignment(id: id, title: "Assignment \(id)", description: "Description \(id)", due: Date(), mark: 10.0 * Double(id), grade: 5.0 * Double(id)))
        }
        
    }
    
}
