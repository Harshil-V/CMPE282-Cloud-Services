//
//  AssignmentViewModel.swift
//  FinalProject
//
//  Created by Ahmed Zaytoun on 4/22/24.
//

import SwiftUI

class AssignmentViewModel: ObservableObject {
    
    public let assignment: Assignment
    
    init(assignment: Assignment) {
        self.assignment = assignment
    }
    
    public var title: String {
        get {
            "Title"
        }
    }
    
    public var icon: Image {
        get {
            Image(systemName: "square.and.pencil")
        }
    }
    
    public var due: String {
        get {
            "No Due Date"
        }
    }
    
}
