//
//  UserAuthenticationViewModel.swift
//  FinalProject
//
//  Created by Ahmed Zaytoun on 4/21/24.
//

import Foundation

class UserAuthenticationViewModel: ObservableObject {
    
    @Published public var showPassword = false
    @Published public var username = ""
    @Published public var password = ""
    @Published public var isLoading = false
    @Published public var loadingInfo = ""
    @Published public private(set) var showIncorrectUsername = false
    @Published public private(set) var noInternetConnection = false
    
    @Published public var shouldShowAuthenticationView = true
    
    
    public func showPasswordToggleAction() {
        self.showPassword.toggle()
    }
    
}
