//
//  UserSignInPasswordFieldView.swift
//  DustyController
//
//  Created by Ahmed Zaytoun on 10/26/23.
//

import SwiftUI

struct UserSignInPasswordFieldView: View {
    @ObservedObject var viewModel: UserAuthenticationViewModel
    var body: some View {
        VStack(alignment: .leading){
            Text("Password")
            HStack{
                if self.viewModel.showPassword{
                    TextField(text: self.$viewModel.password) {
                        
                    }
                    .textContentType(.password)
                    .padding(5.0)
                    .keyboardType(.emailAddress)
                    .frame(minHeight:45.0)
                } else {
                    SecureField(text: self.$viewModel.password) {
                        
                    }
                    .textContentType(.password)
                    .padding(5.0)
                    .keyboardType(.emailAddress)
                    .frame(minHeight:45.0)
                }
                Button(action: {
                    self.viewModel.showPasswordToggleAction()
                }) {
                    Image(systemName: self.viewModel.showPassword ? "eye.slash" : "eye")
                }.padding(.horizontal, 5.0)
            }
            .background(RoundedRectangle(cornerRadius: 10.0).fill(.bar))
        }
    }
}

struct UserSignInPasswordFieldView_Previews: PreviewProvider {
    static var previews: some View {
        UserSignInPasswordFieldView(viewModel: UserAuthenticationViewModel())
    }
}
