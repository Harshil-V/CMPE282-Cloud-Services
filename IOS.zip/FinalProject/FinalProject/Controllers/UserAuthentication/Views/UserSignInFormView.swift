//
//  UserSignInFormView.swift
//  DustyController
//
//  Created by Ahmed Zaytoun on 10/26/23.
//

import SwiftUI

struct UserSignInFormView: View {
    @ObservedObject var viewModel: UserAuthenticationViewModel
    @Environment(\.dismiss) var dismiss
    var body: some View {
        VStack(spacing: 0.0) {
            UserSignInEmailFieldView(viewModel: self.viewModel)
                .padding(10.0)
            UserSignInPasswordFieldView(viewModel: self.viewModel)
                .padding(10.0)
            if self.viewModel.showIncorrectUsername {
                Text("The email or password you entered is incorrect.")
                    .foregroundStyle(Color(.red))
            }
            Button(action: {
                dismiss()
            }) {
                Text("SIGN IN")
                    .font(.system(size: 17.0, weight: .medium))
                    .frame(maxWidth: .infinity, minHeight: 38.0)
            }
            .contentShape(Rectangle())
            .padding(.vertical)
        }
        .background(
            RoundedRectangle(cornerRadius: 10.0)
                .stroke(.blue))
        .padding()
    }
}

struct UserSignInFormView_Previews: PreviewProvider {
    static var previews: some View {
        UserSignInFormView(viewModel:UserAuthenticationViewModel())
    }
}
