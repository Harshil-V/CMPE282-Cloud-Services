//
//  UserAuthenticationView.swift
//  FinalProject
//
//  Created by Ahmed Zaytoun on 4/21/24.
//

import SwiftUI

struct UserAuthenticationView: View {
    @ObservedObject var viewModel: UserAuthenticationViewModel
    var body: some View {
        UserSignInFormView(viewModel: self.viewModel)
    }
}

#Preview {
    UserAuthenticationView(viewModel: UserAuthenticationViewModel())
}
