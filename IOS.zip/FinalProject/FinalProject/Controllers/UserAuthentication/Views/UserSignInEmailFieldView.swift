//
//  UserSignInEmailFieldView.swift
//  DustyController
//
//  Created by Ahmed Zaytoun on 10/26/23.
//

import SwiftUI

struct UserSignInEmailFieldView: View {
    @ObservedObject var viewModel: UserAuthenticationViewModel
    var body: some View {
        VStack(alignment: .leading){
            Text("Your Email")
            HStack{
                TextField(text: self.$viewModel.username) {
                    
                }
                .textInputAutocapitalization(.never)
                .textContentType(.emailAddress)
                .padding(5.0)
                .keyboardType(.emailAddress)
                .frame(minHeight:45.0)
                .background(RoundedRectangle(cornerRadius: 10.0).fill(.bar))
            }
            .background(
                RoundedRectangle(cornerRadius: 10.0)
                    .fill(.white)
            )
        }
    }
}

struct UserSignInEmailFieldView_Previews: PreviewProvider {
    static var previews: some View {
        UserSignInEmailFieldView(viewModel: UserAuthenticationViewModel())
    }
}
