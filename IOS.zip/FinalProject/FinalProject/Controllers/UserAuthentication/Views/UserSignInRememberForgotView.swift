//
//  UserSignInRememberForgotView.swift
//  DustyController
//
//  Created by Ahmed Zaytoun on 10/26/23.
//

import SwiftUI

struct UserSignInRememberForgotView: View {
    @ObservedObject var viewModel: UserAuthenticationViewModel
    var body: some View {
        HStack{
            Spacer()
            Button(action: {
//                self.viewModel.resetPasswordAction()
            }) {
                Text("Forgot Password")
                    .foregroundColor(Color(uiColor: .blue))
            }
        }
    }
}
