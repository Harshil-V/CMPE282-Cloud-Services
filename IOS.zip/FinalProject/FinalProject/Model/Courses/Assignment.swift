//
//  Assignment.swift
//  FinalProject
//
//  Created by Ahmed Zaytoun on 4/22/24.
//

import Foundation

public struct Assignment {
    
    public let id: Int
    public let title: String
    public let description: String
    public let due: Date?
    public let mark: Double
    public let grade: Double?
    
}
