//
//  Course.swift
//  FinalProject
//
//  Created by Ahmed Zaytoun on 4/21/24.
//

import Foundation

public struct Course {
    
    public let id: Int
    public let title: String
    
    public init(id: Int, title: String) {
        self.id = id
        self.title = title
    }
    
}
